﻿using System;
namespace Addiction_Manager
{
    public class User
    {
        public User()
        {
        }
    }
}
