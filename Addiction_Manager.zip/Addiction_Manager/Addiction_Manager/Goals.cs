﻿using System;
namespace Addiction_Manager
{
    public class Goals
    {
        public Goals()
        {
        }
    }
}
